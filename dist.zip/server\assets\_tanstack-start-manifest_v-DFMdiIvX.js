const tsrStartManifest = () => ({ routes: { __root__: { filePath: "C:/Users/Administrator/Desktop/Projetos/status-hub/src/routes/__root.tsx", children: ["/"], assets: void 0, preloads: ["/assets/index-B84ChDY5.js"] }, "/": { filePath: "C:/Users/Administrator/Desktop/Projetos/status-hub/src/routes/index.tsx", children: void 0, assets: void 0, preloads: ["/assets/index-xizKilO1.js"] } }, clientEntry: "/assets/index-B84ChDY5.js" });
export {
  tsrStartManifest
};
